'use strict';

/**
 * @ngdoc function
 * @name digestoApp.controller:IndiceCtrl
 * @description
 * # IndiceCtrl
 * Controller of the digestoApp
 */
angular.module('digestoApp')
  .controller('IndiceCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
