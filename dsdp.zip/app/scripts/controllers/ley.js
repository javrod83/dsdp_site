'use strict';

/**
 * @ngdoc function
 * @name digestoApp.controller:LeyctrlCtrl
 * @description
 * # LeyctrlCtrl
 * Controller of the digestoApp
 */
angular.module('digestoApp')
  .controller('LeyctrlCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
