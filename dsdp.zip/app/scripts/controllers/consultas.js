'use strict';

/**
 * @ngdoc function
 * @name digestoApp.controller:ConsultasctrlCtrl
 * @description
 * # ConsultasctrlCtrl
 * Controller of the digestoApp
 */
angular.module('digestoApp')
  .controller('ConsultasctrlCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
