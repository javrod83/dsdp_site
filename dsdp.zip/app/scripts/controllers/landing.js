'use strict';

/**
 * @ngdoc function
 * @name digestoApp.controller:LandingCtrl
 * @description
 * # LandingCtrl
 * Controller of the digestoApp
 */
angular.module('digestoApp')
  .controller('LandingCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
