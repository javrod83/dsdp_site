'use strict';

/**
 * @ngdoc service
 * @name digestoApp.Consultas
 * @description
 * # Consultas
 * Service in the digestoApp.
 */
angular.module('digestoApp')
  .service('Consultas', function Consultas() {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
