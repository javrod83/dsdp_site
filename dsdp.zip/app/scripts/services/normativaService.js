'use strict';

/**
 * @ngdoc service
 * @name digestoApp.Normativa
 * @description
 * # Normativa
 * Service in the digestoApp.
 */
angular.module('digestoApp')
  .service('Normativa', function Normativa() {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
